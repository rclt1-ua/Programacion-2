// Programación 2 - Práctica 3
// DNI: A8590323
// Nombre: Roberto Loor Tamayo


#include <iostream>
#include <vector>
#include "Util.h"
#include "SNFollowers.h"
#include "SNData.h"
#include "Influencer.h"
#include "Agency.h"


using namespace std;

int main(){
    Influencer *pi;
    Agency ag("Amasando pasta SL",200);
    /*
    SNData::newSocialNetwork("TokTik",0.8,0.1);
    SNData::newSocialNetwork("Infagram",0.6,0.05);
    SNData::newSocialNetwork("YZ",0.5,0.2);
    SNData::newSocialNetwork("JungleBook",0.1,0.1);
    */
    // ag.addInfluencer("Brian", 0.1);
    try{
    ag.searchInfluencer("Brian");
    }catch (exception &e){
        cout << "Hola" << endl;
    }
/*
    



    pi=ag.searchInfluencer("Curro");
    pi->getName();
    pi->getCommission();
    */
    

    

    return 0;
}







