#include "Agency.h"
#include "SNFollowers.h"
#include "SNData.h"
#include "Influencer.h"
#include "Util.h"

Agency::Agency(string name, double initialMoney){ // Constructor de la clase
    this->name = name; // El nombre de la agencia es el nombre que se le pasa
    this->money = initialMoney; // La cantidad de dinero de la agencia es la cantidad de dinero que se le pasa
}

Influencer *Agency::searchInfluencer(string infName){ // Busca un influencer en la lista de influencers
    int recorredor;
    for(recorredor = 0; recorredor < (int)influencers.size(); recorredor++){ // Recorre la lista de influencers
       if(influencers[recorredor].getName() == infName){ // Si el influencer es igual al influencer buscado
          return &influencers[recorredor]; // Devuelve el influencer
        }
    }
    cout << "HOLA1" << endl;
    getchar();
    throw EXCEPTION_INFL_NOT_FOUND ; // Lanza una excepción de que no se encontró el influencer
    cout << "HOLA2" << endl;
    getchar();
}

void Agency::addInfluencer(string infName, double commission){ // Agrega un influencer a la lista de influencers
    try{ // Revisa si hay un influencer con el mismo nombre
        searchInfluencer(infName); // Busca el influencer
        throw ERR_DUPLICATED; // Si lo encuentra, lanza una excepción de que está duplicado
    }catch(exception &e){ // Si no lo encuentra y se lanza una excepción 
        try{ // Intenta agregar el influencer
            Influencer inf(infName); // Crea un influencer con el nombre
            inf.setCommission(commission); // Establece la comisión del influencer
            influencers.push_back(inf); // Agrega el influencer a la lista de influencers
        }catch(exception &e){cout << ERR_WRONG_COMMISSION << endl;} // Si no se puede agregar, lanza una excepción de comisión incorrecta
    }
}

void Agency::addFollowers(string infName, string snName, int nFollowers){ // Agrega seguidores a un influencer
    try{ // Intenta agregar seguidores
        Influencer * inf = searchInfluencer(infName); // Busca el influencer
        inf->addFollowers(snName,nFollowers); // Agrega seguidores al influencer
    }catch(Exception &e){ // Si no se puede agregar seguidores
        cout << ERR_NOT_FOUND << endl; // Imprime que no se encontró
    }
}

void Agency::newEvent(vector<string> infNames, int nsns, string snNames[], double evRats[]){ // Crea un nuevo evento
    int recorredor;
    for(recorredor = 0; recorredor < (int)infNames.size(); recorredor++){ // Recorre la lista de influencers
        try{ // Intenta agregar el evento
            Influencer * inf = searchInfluencer(infNames[recorredor]); // Busca el influencer
            inf->addEvent(nsns,snNames,evRats); // Agrega el evento al influencer
        }catch(exception &e){
            cout << ERR_NOT_FOUND << endl; // Si no se puede agregar el evento, imprime que no se encontró
        } 
    }
}

void Agency::deleteInfluencer(string infName){ // Elimina un influencer de la lista de influencers
    int recorredor;
    for(recorredor = 0; recorredor < (int)influencers.size(); recorredor++){ // Recorre la lista de influencers
        if(influencers[recorredor].getName() == infName){ // Si el influencer es igual al influencer buscado
            money += influencers[recorredor].collectCommission(); // Recolecta la comisión del influencer
            influencers.erase(influencers.begin() + recorredor); // Elimina el influencer de la lista de influencers
            return;
        }
    }
    throw ERR_NOT_FOUND; // Si no se encuentra el influencer, lanza una excepción de que no se encontró
}

double Agency::collectCommissions(){ // Recolecta las comisiones de los influencers
    double comisionRec = 0; // Comisión recolectada
    int recorredor; // Recorredor
    for(recorredor = 0; recorredor < (int)influencers.size(); recorredor++){ // Recorre la lista de influencers
        comisionRec += influencers[recorredor].collectCommission(); // Recolecta la comisión del influencer
    }
    money += comisionRec; // Agrega la comisión recolectada al dinero de la agencia
    return comisionRec; // Devuelve la comisión recolectada
}

ostream & operator<<(ostream &os, const Agency &agency){ // Función que imprime la clase
    os << "Agency: " << agency.name << " [" << agency.money << "]" << endl; // Imprime el nombre de la agencia y la cantidad de dinero
    int recorredor;
    for(recorredor = 0; recorredor < (int)agency.influencers.size(); recorredor++){ // Recorre la lista de influencers
        os << agency.influencers[recorredor]; // Imprime el influencer
    }
    return os; // Devuelve el flujo de salida 
}

